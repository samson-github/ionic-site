/// DISABLED reference path="../deps/NativeScript/bin/dist/definitions/android17.d.ts" />
/// DISABLED reference path="../deps/NativeScript/bin/dist/definitions/ios.d.ts" />

/// <reference path="android17-dummy.d.ts" />
/// <reference path="ios-dummy.d.ts" />

declare function __startCPUProfiler(string): void;
declare function __stopCPUProfiler(string): void;
declare var java: any;
declare var com: any;
