export enum Orientation {
    TopLeft_BottomRight,
    Left_Right,
    BottomLeft_TopRight,
    Bottom_Top,
    BottomRight_TopLeft,
    Right_Left,
    TopRight_BottomLeft,
    Top_Bottom    
}